const express = require('express');
const router = express.Router();
const data = require('../data/data.json');

router.get('/get', async (req, res) => {
    return res.status(200).send({
        users: data.users
    })
})

//Get by username
router.get('/get/:username', (req, res) => {
    const { username } = req.params
    const find = data.users.find((elements)=>{
        return elements.username == username
    })
    res.send(find)
})

//get all friends param username user
router.get('/get/allFriends/:username', (req, res) => {
    const { username } = req.params
    let friendIds = data.users.find((elements)=>{
        if(elements.username == username){
            return elements.friends
        } 
    })

    friendIds = friendIds.friends
    let newFriends = []

    friendIds.forEach(id => {
        data.users.forEach(element => {
            if(id == element.id){
                newFriends.push(element)
            }
        });
    });
    
    return res.status(200).send({
        friends:newFriends
    })
})

//Get user by ID
router.get('/get/user/:id', (req, res) => {
    const { id } = req.params
    const find = data.users.find((element)=>{
        return element.id == id
    })

    return res.status(200).send(
        find
    )
})

router.get('/chats/:idUser/:idFriend', (req, res) => {
    const {idUser, idFriend } = req.params
    let chats = data.chats
    let newChats = []
    chats.forEach(element => {
        if((element.from == idUser && element.to == idFriend) || (element.from == idFriend && element.to == idUser)){
            newChats.push(element)
        }
    });

    return res.status(200).send({
        chats:newChats
    })
})

router.post('/chats/:idUser/:idFriend/:message', (req, res) => {
    const {idUser, idFriend, message } = req.params
    let newID = data.chats.length + 1
    let newChat ={
        id:newID,
        context:message,
        from:idUser,
        to:idFriend
    }
    data.chats.push(newChat)

    return res.status(201).send({
        message: newChat
    })
})
module.exports = router